package com.springboot.web.library.module2;

import com.springboot.web.library.commons.dtos.Person;

public class Module2App {
    Person person;

    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
