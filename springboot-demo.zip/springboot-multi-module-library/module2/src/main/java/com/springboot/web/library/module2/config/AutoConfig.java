package com.springboot.web.library.module2.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AutoConfig {}
