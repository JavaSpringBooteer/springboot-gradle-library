package com.springboot.web.library.commons.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AutoConfig {}
