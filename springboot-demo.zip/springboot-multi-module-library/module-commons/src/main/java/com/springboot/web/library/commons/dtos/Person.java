package com.springboot.web.library.commons.dtos;

import lombok.Data;

@Data
public class Person {
    private String name;
}
