package com.springboot.web.library.module1;

class EntityServiceApplicationTests {

    void contextLoads() {}
}
