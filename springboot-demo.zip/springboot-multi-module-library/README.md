# Spring Boot multi module project

### More detail can be found [medium post](https://medium.com/@sable.dhiraj/spring-boot-multi-module-project-b984888a35d9) 

## How to run spring boot module

* How to start Application: ./gradlew :entity-service:bootRun